/* ORBIT — Screen 1: Dashboard Ejecutivo */
function ScreenDashboard({ data, vendedorFiltro }){
  const k = data.kpisGerencia;
  const proyeccion = (k.acumulado_mes / 19) * 30;  // simplistic projection from day 19
  const diff = proyeccion - k.objetivo_mes;

  // sparklines
  const realSpark = data.dailyEvolution.filter(d=>d.real!=null).map(d=>d.real);
  const cccSpark = [3,7,9,12,8,15,18,22,19,24];

  const vendsOrdenados = [...data.vendedores].sort((a,b)=>b.avance-a.avance);

  return React.createElement(React.Fragment,null,
    // Section A — KPIs primarios
    React.createElement("div",{className:"grid cols-6",style:{marginBottom:14}},
      React.createElement(KpiCard,{
        label:"VENTA ACUMULADA", kind:"ok",
        value: fmtMoney(k.acumulado_mes),
        icon: React.createElement(Ic.zap,{size:14}),
        delta: 12.4, deltaLabel:"vs mes anterior",
        spark: React.createElement(Sparkline,{data:realSpark, w:60, h:22})
      }),
      React.createElement(KpiCard,{
        label:"VENTA DEL DÍA", kind:"warn",
        value: fmtMoney(k.venta_dia),
        icon: React.createElement(Ic.bottle,{size:14}),
        hint:"Objetivo "+fmtMoney(k.objetivo_dia),
        delta: -16.3, deltaLabel:"vs objetivo"
      }),
      React.createElement(KpiCard,{
        label:"OBJETIVO MENSUAL",
        value: fmtMoney(k.objetivo_mes),
        icon: React.createElement(Ic.target,{size:14}),
        hint:"19 días corridos · 11 días restantes"
      }),
      React.createElement(KpiCard,{
        label:"AVANCE %", kind:"ok",
        value: k.avance_pct.toFixed(1), unit:"%",
        icon: React.createElement(Ic.trend,{size:14}),
        delta: 4.2, deltaLabel:"vs ayer"
      }),
      React.createElement(KpiCard,{
        label:"TENDENCIA PROYECTADA", kind:"warn",
        value: "96.8", unit:"%",
        icon: React.createElement(Ic.flame,{size:14}),
        hint:"Cierre proyectado al 30/05"
      }),
      React.createElement(KpiCard,{
        label:"DIFERENCIA VS OBJ", kind:"bad",
        value: "-"+fmtMoney(Math.abs(diff)),
        icon: React.createElement(Ic.arrowDown,{size:14}),
        hint:"Brecha al cierre proyectado"
      }),
    ),

    // Section A2 — KPIs operativos
    React.createElement("div",{className:"grid cols-6",style:{marginBottom:22}},
      React.createElement(KpiCard,{
        label:"CCC ACUMULADOS",
        value: k.ccc_mes,
        icon: React.createElement(Ic.users,{size:14}),
        spark: React.createElement(Sparkline,{data:cccSpark, w:60, h:22, color:"#4DA3FF"})
      }),
      React.createElement(KpiCard,{
        label:"CCC DEL DÍA",
        value: k.ccc_dia, kind:"info",
        icon: React.createElement(Ic.users,{size:14}),
        hint:"24 de 38 esperados"
      }),
      React.createElement(KpiCard,{
        label:"BOTELLAS DEL DÍA",
        value: k.botellas_dia.toLocaleString("es-AR"),
        icon: React.createElement(Ic.bottle,{size:14}),
        delta: 8.1
      }),
      React.createElement(KpiCard,{
        label:"CLIENTES C/COMPRA",
        value: k.clientes_compra,
        icon: React.createElement(Ic.store,{size:14}),
        hint:"de 344 visitados"
      }),
      React.createElement(KpiCard,{
        label:"COBERTURA GENERAL", kind:"warn",
        value: k.cobertura_general.toFixed(1), unit:"%",
        icon: React.createElement(Ic.flag,{size:14}),
        delta: 2.3
      }),
      React.createElement(KpiCard,{
        label:"CUMPLIMIENTO 11T", kind:"bad",
        value: k.cumplimiento_11t.toFixed(1), unit:"%",
        icon: React.createElement(Ic.flame,{size:14}),
        hint:"Empuje requerido"
      }),
    ),

    // Section B — gráfico evolución + donut + ranking
    React.createElement("div",{className:"grid cols-12",style:{marginBottom:22, gap:14}},
      // Evolución mensual
      React.createElement("div",{className:"card", style:{gridColumn:"span 8"}},
        React.createElement("div",{className:"card-head"},
          React.createElement("div",null,
            React.createElement("h3",{className:"card-title"}, "Evolución mensual — Real vs Plan"),
            React.createElement("div",{className:"card-sub"}, "Acumulado diario · Mayo 2026")
          ),
          React.createElement("div",{className:"row",style:{gap:14, fontSize:11}},
            React.createElement("span",{className:"row",style:{gap:6}},
              React.createElement("span",{style:{width:10,height:2,background:"#5BC23A",borderRadius:1,boxShadow:"0 0 6px #5BC23A"}}),
              "Real"),
            React.createElement("span",{className:"row",style:{gap:6}},
              React.createElement("span",{style:{width:10,height:2,background:"rgba(255,255,255,.4)",borderRadius:1,borderTop:"1px dashed #fff"}}),
              "Plan"),
          )
        ),
        React.createElement("div",{className:"card-body"},
          React.createElement(CumulativeChart,{data: data.dailyEvolution})
        )
      ),

      // Donut
      React.createElement("div",{className:"card", style:{gridColumn:"span 4"}},
        React.createElement("div",{className:"card-head"},
          React.createElement("div",null,
            React.createElement("h3",{className:"card-title"}, "Avance del mes"),
            React.createElement("div",{className:"card-sub"}, "Cumplimiento del objetivo")
          )
        ),
        React.createElement("div",{className:"card-body",style:{display:"flex",flexDirection:"column",alignItems:"center",gap:18}},
          React.createElement(Donut,{value: k.avance_pct, label: k.avance_pct.toFixed(1)+"%", subLabel:"Cumplido"}),
          React.createElement("div",{style:{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14,width:"100%",marginTop:6}},
            React.createElement("div",null,
              React.createElement("div",{className:"muted",style:{fontSize:11,letterSpacing:1.2,textTransform:"uppercase"}}, "Logrado"),
              React.createElement("div",{className:"f-display tnum",style:{fontSize:18,fontWeight:700,marginTop:3}}, fmtMoney(k.acumulado_mes))
            ),
            React.createElement("div",{style:{textAlign:"right"}},
              React.createElement("div",{className:"muted",style:{fontSize:11,letterSpacing:1.2,textTransform:"uppercase"}}, "Falta"),
              React.createElement("div",{className:"f-display tnum",style:{fontSize:18,fontWeight:700,marginTop:3,color:"var(--warn)"}}, fmtMoney(k.objetivo_mes - k.acumulado_mes))
            ),
          )
        )
      ),
    ),

    // Section C — Ranking + Cobertura segmento
    React.createElement("div",{className:"grid cols-12",style:{gap:14}},
      // Ranking
      React.createElement("div",{className:"card",style:{gridColumn:"span 8"}},
        React.createElement("div",{className:"card-head"},
          React.createElement("div",null,
            React.createElement("h3",{className:"card-title"}, "Ranking de vendedores"),
            React.createElement("div",{className:"card-sub"}, "Avance vs objetivo mensual · Equipo Peñaflor")
          ),
          React.createElement("div",{className:"row",style:{gap:6}},
            React.createElement("button",{className:"btn btn-sm btn-ghost"}, "Avance"),
            React.createElement("button",{className:"btn btn-sm btn-ghost"}, "CCC"),
            React.createElement("button",{className:"btn btn-sm btn-ghost"}, "11T"),
          )
        ),
        React.createElement("div",{className:"card-body",style:{paddingTop:6}},
          React.createElement(HBars,{
            valueFmt: v => fmtMoney(v),
            max: Math.max(...data.vendedores.map(v=>v.objetivo)),
            rows: vendsOrdenados.map(v=>{
              const kind = v.avance>=100? "ok" : v.avance>=60? "info" : v.avance>=30? "warn" : "bad";
              const color = v.avance>=100? "#5BC23A" : v.avance>=60? "#4DA3FF" : v.avance>=30? "#F2B544" : "#FF5D5D";
              return {
                label: v.nombre + " · " + v.id,
                dot: v.color,
                value: v.acumulado,
                target: v.objetivo,
                color,
                tag: v.avance.toFixed(1)+"%",
                tagKind: kind,
                delta: v.avance - 60,
              };
            })
          })
        )
      ),

      // Cobertura segmento
      React.createElement("div",{className:"card",style:{gridColumn:"span 4"}},
        React.createElement("div",{className:"card-head"},
          React.createElement("div",null,
            React.createElement("h3",{className:"card-title"}, "Cobertura por segmento"),
            React.createElement("div",{className:"card-sub"}, "Clientes con cobertura válida")
          )
        ),
        React.createElement("div",{className:"card-body",style:{display:"flex",flexDirection:"column",gap:18}},
          data.segmentos.map(s=>{
            const pct = (s.cubiertos/s.clientes)*100;
            const kind = pct>=70? "" : pct>=50? "warn" : "bad";
            return React.createElement("div",{key:s.id},
              React.createElement("div",{className:"row between",style:{marginBottom:8}},
                React.createElement("div",null,
                  React.createElement("div",{style:{fontSize:13,fontWeight:600}}, s.nombre),
                  React.createElement("div",{className:"muted",style:{fontSize:11,marginTop:2}}, "Mín. "+s.req+" botellas · "+s.clientes+" clientes")
                ),
                React.createElement("div",{style:{textAlign:"right"}},
                  React.createElement("div",{className:"f-display tnum",style:{fontSize:20,fontWeight:700}}, pct.toFixed(0)+"%"),
                  React.createElement("div",{className:"muted",style:{fontSize:11,marginTop:1}}, s.cubiertos+"/"+s.clientes)
                )
              ),
              React.createElement("div",{className:"bar"+(kind?" "+kind:"")},
                React.createElement("i",{style:{width:pct+"%"}})
              )
            );
          })
        )
      )
    )
  );
}
window.ScreenDashboard = ScreenDashboard;
