/* ORBIT — shared data (real values from the system) */
window.ORBIT_DATA = {
  fecha: "Lunes 04 de Mayo, 2026",
  fechaCorta: "04 May 2026",
  lastSync: "07:14",
  diasVisita: ["LU","MA","MI","JU","VI","SA"],
  diaActivo: "MA",

  vendedores: [
    { id:"V3",  nombre:"Nadia Gambino",            zona:"Arroyito",      color:"#7BD8B8", avance:14.22, objetivo:6001600,    acumulado:853427,    ccc:0,  t11:0,  clientes:49, alertas:49, segmento_excluye:["AUTOSERVICIO"] },
    { id:"V4",  nombre:"Angel Gribaudo",           zona:"Centro",        color:"#F2B544", avance:14.90, objetivo:60561600,   acumulado:9023677,   ccc:0,  t11:0,  clientes:51, alertas:51 },
    { id:"V6",  nombre:"Andrea Peyronel",          zona:"Norte",         color:"#5BC23A", avance:142.19,objetivo:43102400,   acumulado:61289123,  ccc:0,  t11:0,  clientes:70, alertas:70 },
    { id:"V7",  nombre:"Guillermo Jofre",          zona:"Sur",           color:"#9B7BFF", avance:33.32, objetivo:10868000,   acumulado:3621215,   ccc:0,  t11:0,  clientes:60, alertas:60 },
    { id:"V8",  nombre:"Vanesa Alvarez",           zona:"Oeste KAFF",    color:"#4DA3FF", avance:32.01, objetivo:107210400,  acumulado:34316609,  ccc:0,  t11:0,  clientes:53, alertas:53 },
    { id:"V9",  nombre:"Fernando Sanchez",         zona:"On Premise",    color:"#FF9D5C", avance:240.30,objetivo:46332000,   acumulado:111325156, ccc:0,  t11:0,  clientes:21, alertas:21 },
    { id:"V10", nombre:"Milagros Ortega",          zona:"Arroyito",      color:"#FF5D8B", avance:55.05, objetivo:55924000,   acumulado:30786162,  ccc:0,  t11:0,  clientes:40, alertas:40 },
  ],

  // Aggregated KPIs for the board
  kpisGerencia: {
    objetivo_mes: 330000000,
    acumulado_mes: 251215369,
    avance_pct: 76.1,
    venta_dia: 18412300,
    objetivo_dia: 22000000,
    ccc_mes: 412,
    ccc_dia: 24,
    botellas_dia: 1837,
    clientes_compra: 184,
    cobertura_general: 58.4,
    cumplimiento_11t: 47.2,
    tendencia: 96.8, // proyectado vs objetivo
    diff_objetivo: -8784631,
  },

  // Daily evolution (1..31)
  dailyEvolution: [
    { d:1, real: 9200000, plan: 11000000 },
    { d:2, real: 18900000, plan: 22000000 },
    { d:3, real: 31200000, plan: 33000000 },
    { d:4, real: 42000000, plan: 44000000 },
    { d:5, real: 55400000, plan: 55000000 },
    { d:6, real: 71200000, plan: 66000000 },
    { d:7, real: 88100000, plan: 77000000 },
    { d:8, real: 99800000, plan: 88000000 },
    { d:9, real: 116200000, plan: 99000000 },
    { d:10, real: 132400000, plan: 110000000 },
    { d:11, real: 148000000, plan: 121000000 },
    { d:12, real: 161000000, plan: 132000000 },
    { d:13, real: 175200000, plan: 143000000 },
    { d:14, real: 188900000, plan: 154000000 },
    { d:15, real: 203100000, plan: 165000000 },
    { d:16, real: 215400000, plan: 176000000 },
    { d:17, real: 226200000, plan: 187000000 },
    { d:18, real: 238900000, plan: 198000000 },
    { d:19, real: 251215369, plan: 209000000, hoy:true },
    { d:20, real: null, plan: 220000000 },
    { d:21, real: null, plan: 231000000 },
    { d:22, real: null, plan: 242000000 },
    { d:23, real: null, plan: 253000000 },
    { d:24, real: null, plan: 264000000 },
    { d:25, real: null, plan: 275000000 },
    { d:26, real: null, plan: 286000000 },
    { d:27, real: null, plan: 297000000 },
    { d:28, real: null, plan: 308000000 },
    { d:29, real: null, plan: 319000000 },
    { d:30, real: null, plan: 330000000 },
  ],

  segmentos: [
    { id:"TRADICIONAL", nombre:"Tradicional", req:3, clientes:279, cubiertos:163, color:"#5BC23A" },
    { id:"AUTOSERVICIO", nombre:"Autoservicio", req:6, clientes:43, cubiertos:18, color:"#4DA3FF" },
    { id:"ON_PREMISE_VTK", nombre:"On Premise / Vinoteca", req:6, clientes:21, cubiertos:9, color:"#9B7BFF" },
  ],

  titulares11: [
    { marca:"Trapiche Reserva",   producto:"Malbec 750",   objetivo:344, cubiertos:198, segmento:"Tradicional",  responsable:"Todos" },
    { marca:"Alma Mora",          producto:"Malbec 750",   objetivo:298, cubiertos:172, segmento:"Tradicional",  responsable:"Todos" },
    { marca:"Finca Las Moras",    producto:"Cabernet 750", objetivo:266, cubiertos:113, segmento:"Tradicional",  responsable:"V4, V6" },
    { marca:"Don David",          producto:"Reserva 750",  objetivo:189, cubiertos:142, segmento:"On Premise",   responsable:"V9" },
    { marca:"Trapiche Medalla",   producto:"Malbec 750",   objetivo:174, cubiertos:81,  segmento:"Vinoteca",      responsable:"V9" },
    { marca:"JW Black",           producto:"Whisky 750",   objetivo:154, cubiertos:96,  segmento:"On Premise",   responsable:"V9" },
    { marca:"JW Red",             producto:"Whisky 750",   objetivo:201, cubiertos:88,  segmento:"Tradicional",  responsable:"V4, V7" },
    { marca:"Smirnoff",           producto:"Vodka 750",    objetivo:162, cubiertos:64,  segmento:"Tradicional",  responsable:"V8" },
    { marca:"Gordon's",           producto:"Gin 700",      objetivo:138, cubiertos:42,  segmento:"On Premise",   responsable:"V9" },
    { marca:"Antares",            producto:"Cerveza 473",  objetivo:212, cubiertos:96,  segmento:"On Premise",   responsable:"V9" },
    { marca:"Mascota",            producto:"Vino 750",     objetivo:180, cubiertos:73,  segmento:"Tradicional",  responsable:"V6, V10" },
  ],

  alertas: [
    { id:1, prioridad:"alta",   tipo:"vendedor", titulo:"V4 Gribaudo en zona roja",       detalle:"Avance 14.9% vs 60.3% esperado. Brecha proyectada -ARS 36M.", accion:"Revisar planificación + foco autoservicio", responsable:"V4", impacto:36000000 },
    { id:2, prioridad:"alta",   tipo:"vendedor", titulo:"V3 Nadia Gambino — riesgo",      detalle:"Avance 14.2%. Recordar que NO mide Autoservicio.",            accion:"Reforzar Tradicional + 11T",              responsable:"V3", impacto:5100000 },
    { id:3, prioridad:"alta",   tipo:"cobertura",titulo:"Autoservicio 41.8% cobertura",   detalle:"Alma Mora con baja ejecución en segmento autoservicio.",      accion:"Plan de 6 botellas por punto",            responsable:"V8, V10", impacto:2400000 },
    { id:4, prioridad:"media",  tipo:"plan",     titulo:"Plan V8 pendiente aprobación",   detalle:"Vanesa Alvarez envió plan 06:42. Sin aprobar.",                accion:"Aprobar o ajustar antes de matinal",       responsable:"Gerencia", impacto:0 },
    { id:5, prioridad:"media",  tipo:"11t",      titulo:"11T baja ejecución — Tradicional",detalle:"Faltan 11T en 87 clientes del segmento.",                    accion:"Empuje JW Red, Mascota, Smirnoff",         responsable:"V4, V7, V8", impacto:1800000 },
    { id:6, prioridad:"media",  tipo:"cliente",  titulo:"On Premise — clientes clave sin compra", detalle:"4 clientes top sin pedido en mes.",                    accion:"Visita prioritaria hoy",                    responsable:"V9", impacto:980000 },
    { id:7, prioridad:"baja",   tipo:"oportunidad",titulo:"V6 Peyronel sobre objetivo",   detalle:"142% avance. Oportunidad de empujar 11T faltantes.",          accion:"Cargar 11T en clientes nuevos",            responsable:"V6", impacto:0 },
    { id:8, prioridad:"baja",   tipo:"oportunidad",titulo:"V9 Sanchez cierra mes proyectado 240%", detalle:"Capitalizar para cobertura On Premise.",            accion:"Asignar clientes On Premise nuevos",       responsable:"V9", impacto:0 },
  ],

  // Today's planning per vendedor (gerencia view)
  planes: [
    { vendedor:"V3",  estado:"aprobada",   submitted:"06:38", venta_obj:280000,  ccc_trad:8,  ccc_as:0, ccc_op:0, t11:9,  clientes_clave:["Almacén Don José","Kiosco Sole"], marcas:["Alma Mora","Trapiche Reserva","Mascota"], obs_vendedor:"Foco en reposición Trapiche Reserva por agotado.", obs_gerencia:"OK. Sumar Mascota 750 en clientes top.", original:{venta_obj:240000,t11:7} },
    { vendedor:"V4",  estado:"modificada", submitted:"06:42", venta_obj:2900000, ccc_trad:5,  ccc_as:1, ccc_op:0, t11:11, clientes_clave:["SUPERMERCADO LIDER","Almacén La Esquina","Kiosco Pancho"], marcas:["Trapiche Reserva","Finca Las Moras","JW Red"], obs_vendedor:"Voy a Centro y barrio Norte.", obs_gerencia:"Subo objetivo a 2.9M y agrego JW Red. Ya estás en zona roja.", original:{venta_obj:2422464,ccc_trad:5,ccc_as:1,t11:11,marcas:["Trapiche Reserva","Finca Las Moras"]} },
    { vendedor:"V6",  estado:"enviada",    submitted:"06:51", venta_obj:1850000, ccc_trad:9,  ccc_as:2, ccc_op:0, t11:11, clientes_clave:["Mascota Norte","Despensa Lila"], marcas:["Mascota","Alma Mora","Antares"], obs_vendedor:"Aprovechar mes positivo para sumar 11T.", obs_gerencia:"" },
    { vendedor:"V7",  estado:"pendiente",  submitted:null,    venta_obj:null,    ccc_trad:null,ccc_as:null,ccc_op:0, t11:null,clientes_clave:[], marcas:[], obs_vendedor:"", obs_gerencia:"" },
    { vendedor:"V8",  estado:"enviada",    submitted:"06:42", venta_obj:4200000, ccc_trad:6,  ccc_as:4, ccc_op:0, t11:11, clientes_clave:["Disco Centro","Vea Norte","Carrefour Express"], marcas:["Smirnoff","Trapiche Reserva","JW Red"], obs_vendedor:"Hoy me concentro en autoservicios.", obs_gerencia:"" },
    { vendedor:"V9",  estado:"aprobada",   submitted:"06:30", venta_obj:5800000, ccc_trad:0,  ccc_as:0, ccc_op:8, t11:11, clientes_clave:["Bar Don Pedro","Vinoteca Catena","Restó La Cabaña"], marcas:["Don David","JW Black","Antares","Gordon's"], obs_vendedor:"On Premise + Vinoteca, recorrida completa.", obs_gerencia:"Confirmado. Sumar Trapiche Medalla en vinotecas premium.", original:{marcas:["Don David","JW Black","Antares"]} },
    { vendedor:"V10", estado:"modificada", submitted:"06:55", venta_obj:3100000, ccc_trad:7,  ccc_as:5, ccc_op:0, t11:11, clientes_clave:["Hector Hernandez","Zheng Huijuan","Acevedo Sede Cultural"], marcas:["Alma Mora","Trapiche Reserva","Finca Las Moras"], obs_vendedor:"Recupero Hector y Zheng (caída de compra).", obs_gerencia:"Bien. Agrego Finca Las Moras y subo CCC AS a 5.", original:{ccc_as:3,marcas:["Alma Mora","Trapiche Reserva"]} },
  ],

  clientesCriticos: [
    { id:"2357", nombre:"Hector Ivan Hernandez",      segmento:"Autoservicio",  vendedor:"V10", ultima:"hace 22d",  brecha:28865,  estado:"caida_compra",       accion:"Recuperar ticket — foco Alma Mora, Trapiche Reserva, Antares", prioridad:"alta",   t11:11 },
    { id:"2211", nombre:"Zheng Huijuan",              segmento:"Autoservicio",  vendedor:"V10", ultima:"hace 18d",  brecha:28865,  estado:"caida_compra",       accion:"Recuperar ticket — foco Alma Mora, Smirnoff, JW",              prioridad:"alta",   t11:11 },
    { id:"3144", nombre:"Campregher Irina Gisela",    segmento:"Tradicional",   vendedor:"V10", ultima:"sin compra",brecha:18900,  estado:"sin_compra_mes",     accion:"Reactivar — primer pedido del mes",                            prioridad:"alta",   t11:11 },
    { id:"1325", nombre:"Acevedo M Belen — Sede Cult",segmento:"Tradicional",   vendedor:"V10", ultima:"sin compra",brecha:14200,  estado:"sin_compra_mes",     accion:"Reactivar + completar 11T",                                    prioridad:"media",  t11:11 },
    { id:"2021", nombre:"Achille Paola Beatriz",      segmento:"Tradicional",   vendedor:"V10", ultima:"sin compra",brecha:9100,   estado:"sin_cobertura",      accion:"Mín 3 botellas. Foco Alma Mora + Don David",                   prioridad:"media",  t11:11 },
    { id:"1240", nombre:"Barrale Maria Soledad",      segmento:"Tradicional",   vendedor:"V4",  ultima:"hace 35d",  brecha:21300,  estado:"caida_compra",       accion:"Visita prioritaria + mostrador 11T",                            prioridad:"alta",   t11:11 },
    { id:"139",  nombre:"Dalmazzo Favio Alexis",      segmento:"Tradicional",   vendedor:"V4",  ultima:"sin compra",brecha:11400,  estado:"sin_compra_mes",     accion:"Reactivar — combo Trapiche + JW Red",                          prioridad:"alta",   t11:11 },
    { id:"273",  nombre:"Fontana Daniel Octavio",     segmento:"On Premise",    vendedor:"V9",  ultima:"hace 12d",  brecha:34000,  estado:"compra_baja",        accion:"Subir ticket — Trapiche Medalla + Don David",                  prioridad:"media",  t11:6  },
    { id:"2789", nombre:"Gallegos Rene Alejandro",    segmento:"Tradicional",   vendedor:"V7",  ultima:"sin compra",brecha:8200,   estado:"sin_compra_mes",     accion:"Reactivar y cerrar 11T",                                       prioridad:"baja",   t11:11 },
    { id:"2689", nombre:"Geredin Alejandra Fabiola",  segmento:"Autoservicio",  vendedor:"V8",  ultima:"hace 9d",   brecha:42100,  estado:"sin_cobertura",      accion:"Ampliar a 6 botellas — sumar Smirnoff y Gordon's",            prioridad:"alta",   t11:11 },
    { id:"353",  nombre:"Bauer Marcela Alejandra",    segmento:"Tradicional",   vendedor:"V6",  ultima:"hace 14d",  brecha:6700,   estado:"compra_baja",        accion:"Plan 11T mínimo",                                              prioridad:"baja",   t11:8  },
    { id:"89",   nombre:"Luna Jesica Paola",          segmento:"Tradicional",   vendedor:"V7",  ultima:"sin compra",brecha:7400,   estado:"sin_compra_mes",     accion:"Visita + plan inicial",                                        prioridad:"media",  t11:11 },
  ],
};

// Helpers
window.fmtMoney = n => {
  if (n==null) return "—";
  if (Math.abs(n) >= 1e6) return "$" + (n/1e6).toFixed(1) + "M";
  if (Math.abs(n) >= 1e3) return "$" + (n/1e3).toFixed(0) + "K";
  return "$" + Math.round(n).toLocaleString("es-AR");
};
window.fmtMoneyFull = n => n==null ? "—" : "$" + Math.round(n).toLocaleString("es-AR");
window.fmtPct = n => (n==null ? "—" : (n.toFixed(1).replace(".",",")) + "%");
